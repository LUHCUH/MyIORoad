#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int N=1100000;
char ch[N];
int a[N],tm[N*10],yy[N],ans[N];
void jisuan(int *x,int *sa,int n,int m)
{
    int *y=yy;
    for(int i=1;i<=m;i++)tm[i]=0;
    for(int i=1;i<=n;i++)tm[x[i]]++;
    for(int i=2;i<=m;i++)tm[i]+=tm[i-1];
    for(int i=n;i>=1;i--)sa[tm[x[i]]--]=i;
    for(int k=1,p=0;k<=n;k=k<<1,p=0)
    {
        for(int i=n-k+1;i<=n;i++)y[++p]=i;
        for(int i=1;i<=n;i++)if(sa[i]>k)y[++p]=sa[i]-k;
        for(int i=1;i<=m;i++)tm[i]=0;
        for(int i=1;i<=n;i++)tm[x[i]]++;
        for(int i=2;i<=m;i++)tm[i]+=tm[i-1];
        for(int i=n;i>=1;i--)sa[tm[x[y[i]]]--]=y[i];
        swap(x,y);p=1;x[sa[1]]=1;
        for(int i=2;i<=n;i++)x[sa[i]]=(y[sa[i]]==y[sa[i-1]]&&y[sa[i]+k]==y[sa[i-1]+k])?p:(++p);
        if(p>=n)break;m=p;
    }
}
int fans[N];
int main()
{
    scanf("%s",ch+1);
    int len=strlen(ch+1);
    for(int i=1;i<=len;i++)ch[i+len]=a[i+len]=a[i]=ch[i];len*=2;
    jisuan(a,ans,len,128);
    for(int i=1;i<=len;i++)fans[ans[i]]=i;len/=2;
    for(int i=1;i<=len;i++)printf("%c",ch[fans[i+len-1]]);
    return 0;
}
